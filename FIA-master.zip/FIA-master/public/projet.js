//Declaration des id de mon menu
let IdApprenti= document.getElementById("idApprenti");
let IdRepresentant = document.getElementById("idRepresentant");
let IdEmployeur = document.getElementById("idEmployeur");
let IdContrat = document.getElementById("idContrat");


//---------------------------------
let IdInfoPerso = document.getElementById("infoPerso");
let IdInfoScolaire = document.getElementById("infoScolaire");
let IdInfoEmployeur = document.getElementById("infoEmployeur");
let IdInfoContrat = document.getElementById("infoContrat");
let IdInfoRepresentant = document.getElementById("infoRepresentant");


//Quand je vais cliquer sur representant du menu je fait disparaitre les autres infos pour faire apparaitre juste celle voulu
IdRepresentant.addEventListener("click", Representant);

function Representant(){
	
	//Permet de changer la class d'un element
	document.getElementById('idRepresentant').className = "nav-link active nav-item";
	document.getElementById('idApprenti').className = "nav-link nav-item";
	document.getElementById('idEmployeur').className = "nav-link nav-item";
	document.getElementById('idContrat').className = "nav-link nav-item";
	//----------------------------------------
		
	//si l element display de IdInfoPerso n'est pas sur none alors je le met à none pour ne plus le voir
	if (getComputedStyle(IdInfoPerso).display != "none") {
		
		IdInfoPerso.style.display = "none";
	
    } 
	if (getComputedStyle(IdInfoScolaire).display != "none") {
		IdInfoScolaire.style.display = "none";
    } 
	if (getComputedStyle(IdInfoRepresentant).display != "block") {	
		IdInfoRepresentant.style.display = "block";
    } 
	if (getComputedStyle(IdInfoEmployeur).display != "none") {	
		IdInfoEmployeur.style.display = "none";
    } 
	if (getComputedStyle(IdInfoContrat).display != "none") {
		IdInfoContrat.style.display = "none";
	}
}

//les differents evenements pour ensutie lancer les functions lors de click
IdApprenti.addEventListener("click", Apprenti);
IdEmployeur.addEventListener("click", Employeur);
IdContrat.addEventListener("click", Contrat);
//----------------------------------------------------


function Apprenti(){
	
	//Permet de changer la class d'un element
	document.getElementById('idApprenti').className = "nav-link active nav-item";
	document.getElementById('idRepresentant').className = "nav-link nav-item";
	document.getElementById('idEmployeur').className = "nav-link nav-item";
	document.getElementById('idContrat').className = "nav-link nav-item";
	//----------------------------------------
	
	if (getComputedStyle(IdInfoPerso).display != "block") {
		IdInfoPerso.style.display = "block";
    } 
	if (getComputedStyle(IdInfoScolaire).display != "block") {
		IdInfoScolaire.style.display = "block";
    } 
	if (getComputedStyle(IdInfoEmployeur).display != "none") {
		IdInfoEmployeur.style.display = "none";
    } 
	if (getComputedStyle(IdInfoRepresentant).display != "none") {
		IdInfoRepresentant.style.display = "none";
    } 
	if (getComputedStyle(IdInfoContrat).display != "none") {
		IdInfoContrat.style.display = "none";
    } 
}


function Employeur(){
	
	//Permet de changer la class d'un element
	document.getElementById('idEmployeur').className = "nav-link active nav-item";
	document.getElementById('idRepresentant').className = "nav-link nav-item";
	document.getElementById('idApprenti').className = "nav-link nav-item";
	document.getElementById('idContrat').className = "nav-link nav-item";
	//----------------------------------------
	
	if (getComputedStyle(IdInfoPerso).display != "none") {
		IdInfoPerso.style.display = "none";
    } 
	if (getComputedStyle(IdInfoScolaire).display != "none") {
		IdInfoScolaire.style.display = "none";
    } 
	if (getComputedStyle(IdInfoEmployeur).display != "block") {
		IdInfoEmployeur.style.display = "block";
    } 
	if (getComputedStyle(IdInfoRepresentant).display != "none") {
		IdInfoRepresentant.style.display = "none";
    } 
	if (getComputedStyle(IdInfoContrat).display != "none") {
		IdInfoContrat.style.display = "none";
    }
}


function Contrat(){
	
	//Permet de changer la class d'un element
	document.getElementById('idContrat').className = "nav-link active nav-item";
	document.getElementById('idRepresentant').className = "nav-link nav-item";
	document.getElementById('idApprenti').className = "nav-link nav-item";
	document.getElementById('idEmployeur').className = "nav-link nav-item";
	//----------------------------------------
	
	if (getComputedStyle(IdInfoPerso).display != "none") {
		IdInfoPerso.style.display = "none";
    } 
	if (getComputedStyle(IdInfoScolaire).display != "none") {
		IdInfoScolaire.style.display = "none";
    } 
	if (getComputedStyle(IdInfoContrat).display != "block") {
		IdInfoContrat.style.display = "block";
    } 
	if (getComputedStyle(IdInfoEmployeur).display != "none") {
		IdInfoEmployeur.style.display = "none";
    } 
	if (getComputedStyle(IdInfoRepresentant).display != "none") {
		IdInfoRepresentant.style.display = "none";
    } 
}



			
			