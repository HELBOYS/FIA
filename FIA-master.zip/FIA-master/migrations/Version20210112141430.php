<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20210112141430 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE SEQUENCE administrateur_id_seq INCREMENT BY 1 MINVALUE 1 START 1');
        $this->addSql('CREATE SEQUENCE apprenti_id_seq INCREMENT BY 1 MINVALUE 1 START 1');
        $this->addSql('CREATE SEQUENCE banque_id_seq INCREMENT BY 1 MINVALUE 1 START 1');
        $this->addSql('CREATE SEQUENCE classe_id_seq INCREMENT BY 1 MINVALUE 1 START 1');
        $this->addSql('CREATE SEQUENCE contrat_id_seq INCREMENT BY 1 MINVALUE 1 START 1');
        $this->addSql('CREATE SEQUENCE departement_id_seq INCREMENT BY 1 MINVALUE 1 START 1');
        $this->addSql('CREATE SEQUENCE diplome_id_seq INCREMENT BY 1 MINVALUE 1 START 1');
        $this->addSql('CREATE SEQUENCE entreprise_id_seq INCREMENT BY 1 MINVALUE 1 START 1');
        $this->addSql('CREATE SEQUENCE maitre_apprentissage_id_seq INCREMENT BY 1 MINVALUE 1 START 1');
        $this->addSql('CREATE SEQUENCE parenter_id_seq INCREMENT BY 1 MINVALUE 1 START 1');
        $this->addSql('CREATE SEQUENCE profession_id_seq INCREMENT BY 1 MINVALUE 1 START 1');
        $this->addSql('CREATE SEQUENCE promotion_id_seq INCREMENT BY 1 MINVALUE 1 START 1');
        $this->addSql('CREATE SEQUENCE representant_id_seq INCREMENT BY 1 MINVALUE 1 START 1');
        $this->addSql('CREATE SEQUENCE specialite_id_seq INCREMENT BY 1 MINVALUE 1 START 1');
        $this->addSql('CREATE SEQUENCE utilisateur_id_seq INCREMENT BY 1 MINVALUE 1 START 1');
        $this->addSql('CREATE SEQUENCE ville_id_seq INCREMENT BY 1 MINVALUE 1 START 1');
        $this->addSql('CREATE TABLE administrateur (id INT NOT NULL, un_utilisateur_id INT NOT NULL, PRIMARY KEY(id))');
        $this->addSql('CREATE UNIQUE INDEX UNIQ_32EB52E8B0141749 ON administrateur (un_utilisateur_id)');
        $this->addSql('CREATE TABLE apprenti (id INT NOT NULL, lieu_naiss_id INT NOT NULL, une_ville_id INT NOT NULL, une_promotion_id INT NOT NULL, une_classe_id INT NOT NULL, un_diplome_id INT NOT NULL, une_banque_id INT NOT NULL, un_ma_id INT NOT NULL, une_specialite_id INT NOT NULL, un_utilisateur_id INT NOT NULL, nom VARCHAR(255) NOT NULL, prenom VARCHAR(255) NOT NULL, sexe BOOLEAN NOT NULL, adresse VARCHAR(255) NOT NULL, adresse_plus VARCHAR(255) NOT NULL, date_naiss DATE NOT NULL, tel VARCHAR(12) NOT NULL, mail VARCHAR(255) NOT NULL, iban VARCHAR(255) NOT NULL, annee_obention_diplome DATE NOT NULL, PRIMARY KEY(id))');
        $this->addSql('CREATE INDEX IDX_2CB7951C2B6DABBA ON apprenti (lieu_naiss_id)');
        $this->addSql('CREATE INDEX IDX_2CB7951C9DA61379 ON apprenti (une_ville_id)');
        $this->addSql('CREATE INDEX IDX_2CB7951CA8054C37 ON apprenti (une_promotion_id)');
        $this->addSql('CREATE INDEX IDX_2CB7951C6907601B ON apprenti (une_classe_id)');
        $this->addSql('CREATE INDEX IDX_2CB7951C47F82E75 ON apprenti (un_diplome_id)');
        $this->addSql('CREATE INDEX IDX_2CB7951CD1B945CB ON apprenti (une_banque_id)');
        $this->addSql('CREATE INDEX IDX_2CB7951CDCFBF2BF ON apprenti (un_ma_id)');
        $this->addSql('CREATE INDEX IDX_2CB7951C6EF18A1F ON apprenti (une_specialite_id)');
        $this->addSql('CREATE INDEX IDX_2CB7951CB0141749 ON apprenti (un_utilisateur_id)');
        $this->addSql('CREATE TABLE banque (id INT NOT NULL, une_ville_id INT NOT NULL, libelle VARCHAR(255) NOT NULL, bic VARCHAR(34) NOT NULL, PRIMARY KEY(id))');
        $this->addSql('CREATE INDEX IDX_B1F6CB3C9DA61379 ON banque (une_ville_id)');
        $this->addSql('CREATE TABLE classe (id INT NOT NULL, libelle VARCHAR(255) NOT NULL, PRIMARY KEY(id))');
        $this->addSql('CREATE TABLE contrat (id INT NOT NULL, un_apprenti_id INT NOT NULL, une_entreprise_id INT NOT NULL, date_debut DATE NOT NULL, date_fin DATE NOT NULL, PRIMARY KEY(id))');
        $this->addSql('CREATE INDEX IDX_603499934444C1E8 ON contrat (un_apprenti_id)');
        $this->addSql('CREATE INDEX IDX_60349993EBCAC505 ON contrat (une_entreprise_id)');
        $this->addSql('CREATE TABLE departement (id INT NOT NULL, libelle VARCHAR(255) NOT NULL, PRIMARY KEY(id))');
        $this->addSql('CREATE TABLE diplome (id INT NOT NULL, libelle VARCHAR(255) NOT NULL, PRIMARY KEY(id))');
        $this->addSql('CREATE TABLE entreprise (id INT NOT NULL, une_ville_id INT NOT NULL, nom VARCHAR(255) NOT NULL, adresse VARCHAR(255) NOT NULL, adresse_plus VARCHAR(255) NOT NULL, tel VARCHAR(12) NOT NULL, fax VARCHAR(12) NOT NULL, nom_employeur VARCHAR(255) NOT NULL, PRIMARY KEY(id))');
        $this->addSql('CREATE INDEX IDX_D19FA609DA61379 ON entreprise (une_ville_id)');
        $this->addSql('CREATE TABLE maitre_apprentissage (id INT NOT NULL, nom VARCHAR(255) NOT NULL, prenom VARCHAR(255) NOT NULL, mail VARCHAR(255) NOT NULL, PRIMARY KEY(id))');
        $this->addSql('CREATE TABLE parenter (id INT NOT NULL, un_representant_id INT NOT NULL, un_apprenti_id INT NOT NULL, PRIMARY KEY(id))');
        $this->addSql('CREATE INDEX IDX_DD0B921185626B33 ON parenter (un_representant_id)');
        $this->addSql('CREATE INDEX IDX_DD0B92114444C1E8 ON parenter (un_apprenti_id)');
        $this->addSql('CREATE TABLE profession (id INT NOT NULL, libelle VARCHAR(255) NOT NULL, PRIMARY KEY(id))');
        $this->addSql('CREATE TABLE promotion (id INT NOT NULL, annee DATE NOT NULL, PRIMARY KEY(id))');
        $this->addSql('CREATE TABLE representant (id INT NOT NULL, une_ville_id INT NOT NULL, une_profession_id INT NOT NULL, nom VARCHAR(255) NOT NULL, adresse VARCHAR(255) NOT NULL, adresse_plus VARCHAR(255) DEFAULT NULL, tel VARCHAR(12) NOT NULL, PRIMARY KEY(id))');
        $this->addSql('CREATE INDEX IDX_80D5DBC99DA61379 ON representant (une_ville_id)');
        $this->addSql('CREATE INDEX IDX_80D5DBC9B28BE379 ON representant (une_profession_id)');
        $this->addSql('CREATE TABLE specialite (id INT NOT NULL, libelle VARCHAR(255) NOT NULL, PRIMARY KEY(id))');
        $this->addSql('CREATE TABLE utilisateur (id INT NOT NULL, login VARCHAR(255) NOT NULL, password VARCHAR(255) NOT NULL, PRIMARY KEY(id))');
        $this->addSql('CREATE TABLE ville (id INT NOT NULL, un_departement_id INT NOT NULL, libelle VARCHAR(255) NOT NULL, cp INT NOT NULL, PRIMARY KEY(id))');
        $this->addSql('CREATE INDEX IDX_43C3D9C387651618 ON ville (un_departement_id)');
        $this->addSql('ALTER TABLE administrateur ADD CONSTRAINT FK_32EB52E8B0141749 FOREIGN KEY (un_utilisateur_id) REFERENCES utilisateur (id) NOT DEFERRABLE INITIALLY IMMEDIATE');
        $this->addSql('ALTER TABLE apprenti ADD CONSTRAINT FK_2CB7951C2B6DABBA FOREIGN KEY (lieu_naiss_id) REFERENCES ville (id) NOT DEFERRABLE INITIALLY IMMEDIATE');
        $this->addSql('ALTER TABLE apprenti ADD CONSTRAINT FK_2CB7951C9DA61379 FOREIGN KEY (une_ville_id) REFERENCES ville (id) NOT DEFERRABLE INITIALLY IMMEDIATE');
        $this->addSql('ALTER TABLE apprenti ADD CONSTRAINT FK_2CB7951CA8054C37 FOREIGN KEY (une_promotion_id) REFERENCES promotion (id) NOT DEFERRABLE INITIALLY IMMEDIATE');
        $this->addSql('ALTER TABLE apprenti ADD CONSTRAINT FK_2CB7951C6907601B FOREIGN KEY (une_classe_id) REFERENCES classe (id) NOT DEFERRABLE INITIALLY IMMEDIATE');
        $this->addSql('ALTER TABLE apprenti ADD CONSTRAINT FK_2CB7951C47F82E75 FOREIGN KEY (un_diplome_id) REFERENCES diplome (id) NOT DEFERRABLE INITIALLY IMMEDIATE');
        $this->addSql('ALTER TABLE apprenti ADD CONSTRAINT FK_2CB7951CD1B945CB FOREIGN KEY (une_banque_id) REFERENCES banque (id) NOT DEFERRABLE INITIALLY IMMEDIATE');
        $this->addSql('ALTER TABLE apprenti ADD CONSTRAINT FK_2CB7951CDCFBF2BF FOREIGN KEY (un_ma_id) REFERENCES maitre_apprentissage (id) NOT DEFERRABLE INITIALLY IMMEDIATE');
        $this->addSql('ALTER TABLE apprenti ADD CONSTRAINT FK_2CB7951C6EF18A1F FOREIGN KEY (une_specialite_id) REFERENCES specialite (id) NOT DEFERRABLE INITIALLY IMMEDIATE');
        $this->addSql('ALTER TABLE apprenti ADD CONSTRAINT FK_2CB7951CB0141749 FOREIGN KEY (un_utilisateur_id) REFERENCES utilisateur (id) NOT DEFERRABLE INITIALLY IMMEDIATE');
        $this->addSql('ALTER TABLE banque ADD CONSTRAINT FK_B1F6CB3C9DA61379 FOREIGN KEY (une_ville_id) REFERENCES ville (id) NOT DEFERRABLE INITIALLY IMMEDIATE');
        $this->addSql('ALTER TABLE contrat ADD CONSTRAINT FK_603499934444C1E8 FOREIGN KEY (un_apprenti_id) REFERENCES apprenti (id) NOT DEFERRABLE INITIALLY IMMEDIATE');
        $this->addSql('ALTER TABLE contrat ADD CONSTRAINT FK_60349993EBCAC505 FOREIGN KEY (une_entreprise_id) REFERENCES entreprise (id) NOT DEFERRABLE INITIALLY IMMEDIATE');
        $this->addSql('ALTER TABLE entreprise ADD CONSTRAINT FK_D19FA609DA61379 FOREIGN KEY (une_ville_id) REFERENCES ville (id) NOT DEFERRABLE INITIALLY IMMEDIATE');
        $this->addSql('ALTER TABLE parenter ADD CONSTRAINT FK_DD0B921185626B33 FOREIGN KEY (un_representant_id) REFERENCES apprenti (id) NOT DEFERRABLE INITIALLY IMMEDIATE');
        $this->addSql('ALTER TABLE parenter ADD CONSTRAINT FK_DD0B92114444C1E8 FOREIGN KEY (un_apprenti_id) REFERENCES representant (id) NOT DEFERRABLE INITIALLY IMMEDIATE');
        $this->addSql('ALTER TABLE representant ADD CONSTRAINT FK_80D5DBC99DA61379 FOREIGN KEY (une_ville_id) REFERENCES ville (id) NOT DEFERRABLE INITIALLY IMMEDIATE');
        $this->addSql('ALTER TABLE representant ADD CONSTRAINT FK_80D5DBC9B28BE379 FOREIGN KEY (une_profession_id) REFERENCES profession (id) NOT DEFERRABLE INITIALLY IMMEDIATE');
        $this->addSql('ALTER TABLE ville ADD CONSTRAINT FK_43C3D9C387651618 FOREIGN KEY (un_departement_id) REFERENCES departement (id) NOT DEFERRABLE INITIALLY IMMEDIATE');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE SCHEMA public');
        $this->addSql('ALTER TABLE contrat DROP CONSTRAINT FK_603499934444C1E8');
        $this->addSql('ALTER TABLE parenter DROP CONSTRAINT FK_DD0B921185626B33');
        $this->addSql('ALTER TABLE apprenti DROP CONSTRAINT FK_2CB7951CD1B945CB');
        $this->addSql('ALTER TABLE apprenti DROP CONSTRAINT FK_2CB7951C6907601B');
        $this->addSql('ALTER TABLE ville DROP CONSTRAINT FK_43C3D9C387651618');
        $this->addSql('ALTER TABLE apprenti DROP CONSTRAINT FK_2CB7951C47F82E75');
        $this->addSql('ALTER TABLE contrat DROP CONSTRAINT FK_60349993EBCAC505');
        $this->addSql('ALTER TABLE apprenti DROP CONSTRAINT FK_2CB7951CDCFBF2BF');
        $this->addSql('ALTER TABLE representant DROP CONSTRAINT FK_80D5DBC9B28BE379');
        $this->addSql('ALTER TABLE apprenti DROP CONSTRAINT FK_2CB7951CA8054C37');
        $this->addSql('ALTER TABLE parenter DROP CONSTRAINT FK_DD0B92114444C1E8');
        $this->addSql('ALTER TABLE apprenti DROP CONSTRAINT FK_2CB7951C6EF18A1F');
        $this->addSql('ALTER TABLE administrateur DROP CONSTRAINT FK_32EB52E8B0141749');
        $this->addSql('ALTER TABLE apprenti DROP CONSTRAINT FK_2CB7951CB0141749');
        $this->addSql('ALTER TABLE apprenti DROP CONSTRAINT FK_2CB7951C2B6DABBA');
        $this->addSql('ALTER TABLE apprenti DROP CONSTRAINT FK_2CB7951C9DA61379');
        $this->addSql('ALTER TABLE banque DROP CONSTRAINT FK_B1F6CB3C9DA61379');
        $this->addSql('ALTER TABLE entreprise DROP CONSTRAINT FK_D19FA609DA61379');
        $this->addSql('ALTER TABLE representant DROP CONSTRAINT FK_80D5DBC99DA61379');
        $this->addSql('DROP SEQUENCE administrateur_id_seq CASCADE');
        $this->addSql('DROP SEQUENCE apprenti_id_seq CASCADE');
        $this->addSql('DROP SEQUENCE banque_id_seq CASCADE');
        $this->addSql('DROP SEQUENCE classe_id_seq CASCADE');
        $this->addSql('DROP SEQUENCE contrat_id_seq CASCADE');
        $this->addSql('DROP SEQUENCE departement_id_seq CASCADE');
        $this->addSql('DROP SEQUENCE diplome_id_seq CASCADE');
        $this->addSql('DROP SEQUENCE entreprise_id_seq CASCADE');
        $this->addSql('DROP SEQUENCE maitre_apprentissage_id_seq CASCADE');
        $this->addSql('DROP SEQUENCE parenter_id_seq CASCADE');
        $this->addSql('DROP SEQUENCE profession_id_seq CASCADE');
        $this->addSql('DROP SEQUENCE promotion_id_seq CASCADE');
        $this->addSql('DROP SEQUENCE representant_id_seq CASCADE');
        $this->addSql('DROP SEQUENCE specialite_id_seq CASCADE');
        $this->addSql('DROP SEQUENCE utilisateur_id_seq CASCADE');
        $this->addSql('DROP SEQUENCE ville_id_seq CASCADE');
        $this->addSql('DROP TABLE administrateur');
        $this->addSql('DROP TABLE apprenti');
        $this->addSql('DROP TABLE banque');
        $this->addSql('DROP TABLE classe');
        $this->addSql('DROP TABLE contrat');
        $this->addSql('DROP TABLE departement');
        $this->addSql('DROP TABLE diplome');
        $this->addSql('DROP TABLE entreprise');
        $this->addSql('DROP TABLE maitre_apprentissage');
        $this->addSql('DROP TABLE parenter');
        $this->addSql('DROP TABLE profession');
        $this->addSql('DROP TABLE promotion');
        $this->addSql('DROP TABLE representant');
        $this->addSql('DROP TABLE specialite');
        $this->addSql('DROP TABLE utilisateur');
        $this->addSql('DROP TABLE ville');
    }
}
