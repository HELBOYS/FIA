<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20210112143429 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE utilisateur ADD username VARCHAR(25) NOT NULL');
        $this->addSql('ALTER TABLE utilisateur ADD email VARCHAR(60) NOT NULL');
        $this->addSql('ALTER TABLE utilisateur ADD is_active BOOLEAN NOT NULL');
        $this->addSql('ALTER TABLE utilisateur DROP login');
        $this->addSql('ALTER TABLE utilisateur ALTER password TYPE VARCHAR(64)');
        $this->addSql('CREATE UNIQUE INDEX UNIQ_1D1C63B3F85E0677 ON utilisateur (username)');
        $this->addSql('CREATE UNIQUE INDEX UNIQ_1D1C63B3E7927C74 ON utilisateur (email)');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE SCHEMA public');
        $this->addSql('DROP INDEX UNIQ_1D1C63B3F85E0677');
        $this->addSql('DROP INDEX UNIQ_1D1C63B3E7927C74');
        $this->addSql('ALTER TABLE utilisateur ADD login VARCHAR(255) NOT NULL');
        $this->addSql('ALTER TABLE utilisateur DROP username');
        $this->addSql('ALTER TABLE utilisateur DROP email');
        $this->addSql('ALTER TABLE utilisateur DROP is_active');
        $this->addSql('ALTER TABLE utilisateur ALTER password TYPE VARCHAR(255)');
    }
}
