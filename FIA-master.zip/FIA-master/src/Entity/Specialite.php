<?php

namespace App\Entity;

use App\Repository\SpecialiteRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=SpecialiteRepository::class)
 */
class Specialite
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $libelle;

    /**
     * @ORM\OneToMany(targetEntity=Apprenti::class, mappedBy="uneSpecialite")
     */
    private $lesApprentis;

    public function __construct()
    {
        $this->lesApprentis = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getLibelle(): ?string
    {
        return $this->libelle;
    }

    public function setLibelle(string $libelle): self
    {
        $this->libelle = $libelle;

        return $this;
    }

    /**
     * @return Collection|Apprenti[]
     */
    public function getLesApprentis(): Collection
    {
        return $this->lesApprentis;
    }

    public function addLesApprenti(Apprenti $lesApprenti): self
    {
        if (!$this->lesApprentis->contains($lesApprenti)) {
            $this->lesApprentis[] = $lesApprenti;
            $lesApprenti->setUneSpecialite($this);
        }

        return $this;
    }

    public function removeLesApprenti(Apprenti $lesApprenti): self
    {
        if ($this->lesApprentis->removeElement($lesApprenti)) {
            // set the owning side to null (unless already changed)
            if ($lesApprenti->getUneSpecialite() === $this) {
                $lesApprenti->setUneSpecialite(null);
            }
        }

        return $this;
    }
}
