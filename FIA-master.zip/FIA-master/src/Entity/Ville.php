<?php

namespace App\Entity;

use App\Repository\VilleRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=VilleRepository::class)
 */
class Ville
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $libelle;

    /**
     * @ORM\Column(type="integer")
     */
    private $cp;

    /**
     * @ORM\ManyToOne(targetEntity=Departement::class)
     * @ORM\JoinColumn(nullable=false)
     */
    private $unDepartement;

    /**
     * @ORM\OneToMany(targetEntity=Entreprise::class, mappedBy="uneVille")
     */
    private $lesEntreprises;

    /**
     * @ORM\OneToMany(targetEntity=Apprenti::class, mappedBy="uneVille")
     */
    private $lesApprentis;

    public function __construct()
    {
        $this->lesEntreprises = new ArrayCollection();
        $this->lesApprentis = new ArrayCollection();

    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getLibelle(): ?string
    {
        return $this->libelle;
    }

    public function setLibelle(string $libelle): self
    {
        $this->libelle = $libelle;

        return $this;
    }

    public function getCp(): ?int
    {
        return $this->cp;
    }

    public function setCp(int $cp): self
    {
        $this->cp = $cp;

        return $this;
    }

    public function getUnDepartement(): ?Departement
    {
        return $this->unDepartement;
    }

    public function setUnDepartement(?Departement $unDepartement): self
    {
        $this->unDepartement = $unDepartement;

        return $this;
    }

    /**
     * @return Collection|Entreprise[]
     */
    public function getLesEntreprises(): Collection
    {
        return $this->lesEntreprises;
    }

    public function addLesEntreprise(Entreprise $lesEntreprise): self
    {
        if (!$this->lesEntreprises->contains($lesEntreprise)) {
            $this->lesEntreprises[] = $lesEntreprise;
            $lesEntreprise->setUneVille($this);
        }

        return $this;
    }

    public function removeLesEntreprise(Entreprise $lesEntreprise): self
    {
        if ($this->lesEntreprises->removeElement($lesEntreprise)) {
            // set the owning side to null (unless already changed)
            if ($lesEntreprise->getUneVille() === $this) {
                $lesEntreprise->setUneVille(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection|Apprenti[]
     */
    public function getLesApprentis(): Collection
    {
        return $this->lesApprentis;
    }

    public function addLesApprenti(Apprenti $lesApprenti): self
    {
        if (!$this->lesApprentis->contains($lesApprenti)) {
            $this->lesApprentis[] = $lesApprenti;
            $lesApprenti->setUneVille($this);
        }

        return $this;
    }

    public function removeLesApprenti(Apprenti $lesApprenti): self
    {
        if ($this->lesApprentis->removeElement($lesApprenti)) {
            // set the owning side to null (unless already changed)
            if ($lesApprenti->getUneVille() === $this) {
                $lesApprenti->setUneVille(null);
            }
        }

        return $this;
    }
}
