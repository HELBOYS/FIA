<?php

namespace App\Entity;

use App\Repository\ParenterRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=ParenterRepository::class)
 */
class Parenter
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\ManyToOne(targetEntity=Apprenti::class, inversedBy="lesRepresentants")
     * @ORM\JoinColumn(nullable=false)
     */
    private $unRepresentant;

    /**
     * @ORM\ManyToOne(targetEntity=Representant::class, inversedBy="lesApprentis")
     * @ORM\JoinColumn(nullable=false)
     */
    private $unApprenti;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getUnApprenti(): ?Apprenti
    {
        return $this->unApprenti;
    }

    public function setUnApprenti(?Apprenti $unApprenti): self
    {
        $this->unApprenti = $unApprenti;

        return $this;
    }

    public function getUnRepresentant(): ?Representant
    {
        return $this->unRepresentant;
    }

    public function setUnRepresentant(?Representant $unRepresentant): self
    {
        $this->unRepresentant = $unRepresentant;

        return $this;
    }
}
