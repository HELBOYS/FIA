<?php

namespace App\Entity;

use App\Repository\PromotionRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=PromotionRepository::class)
 */
class Promotion
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="date")
     */
    private $annee;

    /**
     * @ORM\OneToMany(targetEntity=Apprenti::class, mappedBy="unePromotion")
     */
    private $lesApprentis;

    public function __construct()
    {
        $this->lesApprentis = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getAnnee(): ?\DateTimeInterface
    {
        return $this->annee;
    }

    public function setAnnee(\DateTimeInterface $annee): self
    {
        $this->annee = $annee;

        return $this;
    }

    /**
     * @return Collection|Apprenti[]
     */
    public function getLesApprentis(): Collection
    {
        return $this->lesApprentis;
    }

    public function addLesApprenti(Apprenti $lesApprenti): self
    {
        if (!$this->lesApprentis->contains($lesApprenti)) {
            $this->lesApprentis[] = $lesApprenti;
            $lesApprenti->setUnePromotion($this);
        }

        return $this;
    }

    public function removeLesApprenti(Apprenti $lesApprenti): self
    {
        if ($this->lesApprentis->removeElement($lesApprenti)) {
            // set the owning side to null (unless already changed)
            if ($lesApprenti->getUnePromotion() === $this) {
                $lesApprenti->setUnePromotion(null);
            }
        }

        return $this;
    }
}
