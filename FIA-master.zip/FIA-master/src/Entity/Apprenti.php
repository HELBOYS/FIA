<?php

namespace App\Entity;

use App\Repository\ApprentiRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=ApprentiRepository::class)
 */
class Apprenti
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $nom;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $prenom;

    /**
     * @ORM\Column(type="boolean")
     */
    private $sexe;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $adresse;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $adressePlus;

    /**
     * @ORM\Column(type="date")
     */
    private $dateNaiss;

    /**
     * @ORM\ManyToOne(targetEntity=Ville::class)
     * @ORM\JoinColumn(nullable=false)
     */
    private $lieuNaiss;

    /**
     * @ORM\Column(type="string", length=12)
     */
    private $tel;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $mail;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $IBAN;

    /**
     * @ORM\ManyToOne(targetEntity=Ville::class, inversedBy="lesApprentis")
     * @ORM\JoinColumn(nullable=false)
     */
    private $uneVille;

    /**
     * @ORM\ManyToOne(targetEntity=Promotion::class, inversedBy="lesApprentis")
     * @ORM\JoinColumn(nullable=false)
     */
    private $unePromotion;

    /**
     * @ORM\ManyToOne(targetEntity=Classe::class, inversedBy="lesApprentisParClasse")
     * @ORM\JoinColumn(nullable=false)
     */
    private $uneClasse;

    /**
     * @ORM\ManyToOne(targetEntity=Diplome::class)
     * @ORM\JoinColumn(nullable=false)
     */
    private $unDiplome;

    /**
     * @ORM\ManyToOne(targetEntity=Banque::class)
     * @ORM\JoinColumn(nullable=false)
     */
    private $uneBanque;

    /**
     * @ORM\ManyToOne(targetEntity=MaitreApprentissage::class)
     * @ORM\JoinColumn(nullable=false)
     */
    private $unMA;

    /**
     * @ORM\ManyToOne(targetEntity=Specialite::class, inversedBy="lesApprentis")
     * @ORM\JoinColumn(nullable=false)
     */
    private $uneSpecialite;

    /**
     * @ORM\ManyToOne(targetEntity=Utilisateur::class)
     * @ORM\JoinColumn(nullable=false)
     */
    private $unUtilisateur;

    /**
     * @ORM\OneToMany(targetEntity=Parenter::class, mappedBy="unRepresentant")
     */
    private $lesRepresentants;

    /**
     * @ORM\Column(type="date")
     */
    private $anneeObentionDiplome;


    public function __construct()
    {
        $this->lesRepresentants     = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNom(): ?string
    {
        return $this->nom;
    }

    public function setNom(string $nom): self
    {
        $this->nom = $nom;

        return $this;
    }

    public function getPrenom(): ?string
    {
        return $this->prenom;
    }

    public function setPrenom(string $prenom): self
    {
        $this->prenom = $prenom;

        return $this;
    }

    public function getSexe(): ?bool
    {
        return $this->sexe;
    }

    public function setSexe(bool $sexe): self
    {
        $this->sexe = $sexe;

        return $this;
    }

    public function getAdresse(): ?string
    {
        return $this->adresse;
    }

    public function setAdresse(string $adresse): self
    {
        $this->adresse = $adresse;

        return $this;
    }

    public function getAdressePlus(): ?string
    {
        return $this->adressePlus;
    }

    public function setAdressePlus(string $adressePlus): self
    {
        $this->adressePlus = $adressePlus;

        return $this;
    }

    public function getDateNaiss(): ?\DateTimeInterface
    {
        return $this->dateNaiss;
    }

    public function setDateNaiss(\DateTimeInterface $dateNaiss): self
    {
        $this->dateNaiss = $dateNaiss;

        return $this;
    }

    public function getLieuNaiss(): ?Ville
    {
        return $this->lieuNaiss;
    }

    public function setLieuNaiss(?Ville $lieuNaiss): self
    {
        $this->lieuNaiss = $lieuNaiss;

        return $this;
    }

    public function getTel(): ?string
    {
        return $this->tel;
    }

    public function setTel(string $tel): self
    {
        $this->tel = $tel;

        return $this;
    }

    public function getMail(): ?string
    {
        return $this->mail;
    }

    public function setMail(string $mail): self
    {
        $this->mail = $mail;

        return $this;
    }

    public function getIBAN(): ?string
    {
        return $this->IBAN;
    }

    public function setIBAN(string $IBAN): self
    {
        $this->IBAN = $IBAN;

        return $this;
    }

    public function getUneVille(): ?Ville
    {
        return $this->uneVille;
    }

    public function setUneVille(?Ville $uneVille): self
    {
        $this->uneVille = $uneVille;

        return $this;
    }

    public function getUnePromotion(): ?Promotion
    {
        return $this->unePromotion;
    }

    public function setUnePromotion(?Promotion $unePromotion): self
    {
        $this->unePromotion = $unePromotion;

        return $this;
    }

    public function getUneClasse(): ?Classe
    {
        return $this->uneClasse;
    }

    public function setUneClasse(?Classe $uneClasse): self
    {
        $this->uneClasse = $uneClasse;

        return $this;
    }

    public function getUnDiplome(): ?Diplome
    {
        return $this->unDiplome;
    }

    public function setUnDiplome(?Diplome $unDiplome): self
    {
        $this->unDiplome = $unDiplome;

        return $this;
    }

    public function getUneBanque(): ?Banque
    {
        return $this->uneBanque;
    }

    public function setUneBanque(?Banque $uneBanque): self
    {
        $this->uneBanque = $uneBanque;

        return $this;
    }

    public function getUnMA(): ?MaitreApprentissage
    {
        return $this->unMA;
    }

    public function setUnMA(?MaitreApprentissage $unMA): self
    {
        $this->unMA = $unMA;

        return $this;
    }

    public function getUneSpecialite(): ?Specialite
    {
        return $this->uneSpecialite;
    }

    public function setUneSpecialite(?Specialite $uneSpecialite): self
    {
        $this->uneSpecialite = $uneSpecialite;

        return $this;
    }

    public function getUnUtilisateur(): ?Utilisateur
    {
        return $this->unUtilisateur;
    }

    public function setUnUtilisateur(?Utilisateur $unUtilisateur): self
    {
        $this->unUtilisateur = $unUtilisateur;

        return $this;
    }

    /**
     * @return Collection|Parenter[]
     */
    public function getLesRepresentants(): Collection
    {
        return $this->lesRepresentants;
    }

    public function addLesRepresentant(Parenter $lesRepresentant): self
    {
        if (!$this->lesRepresentants->contains($lesRepresentant)) {
            $this->lesRepresentants[] = $lesRepresentant;
            $lesRepresentant->setUnApprenti($this);
        }

        return $this;
    }

    public function removeLesRepresentant(Parenter $lesRepresentant): self
    {
        if ($this->lesRepresentants->removeElement($lesRepresentant)) {
            // set the owning side to null (unless already changed)
            if ($lesRepresentant->getUnApprenti() === $this) {
                $lesRepresentant->setUnApprenti(null);
            }
        }

        return $this;
    }

    public function getAnneeObentionDiplome(): ?\DateTimeInterface
    {
        return $this->anneeObentionDiplome;
    }

    public function setAnneeObentionDiplome(\DateTimeInterface $anneeObentionDiplome): self
    {
        $this->anneeObentionDiplome = $anneeObentionDiplome;

        return $this;
    }

}