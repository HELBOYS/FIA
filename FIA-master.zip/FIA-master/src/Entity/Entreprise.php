<?php

namespace App\Entity;

use App\Repository\EntrepriseRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=EntrepriseRepository::class)
 */
class Entreprise
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $nom;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $adresse;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $adressePlus;

    /**
     * @ORM\Column(type="string", length=12)
     */
    private $tel;

    /**
     * @ORM\Column(type="string", length=12)
     */
    private $fax;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $nomEmployeur;

    /**
     * @ORM\ManyToOne(targetEntity=Ville::class, inversedBy="lesEntreprises")
     * @ORM\JoinColumn(nullable=false)
     */
    private $uneVille;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNom(): ?string
    {
        return $this->nom;
    }

    public function setNom(string $nom): self
    {
        $this->nom = $nom;

        return $this;
    }

    public function getAdresse(): ?string
    {
        return $this->adresse;
    }

    public function setAdresse(string $adresse): self
    {
        $this->adresse = $adresse;

        return $this;
    }

    public function getAdressePlus(): ?string
    {
        return $this->adressePlus;
    }

    public function setAdressePlus(string $adressePlus): self
    {
        $this->adressePlus = $adressePlus;

        return $this;
    }

    public function getTel(): ?string
    {
        return $this->tel;
    }

    public function setTel(string $tel): self
    {
        $this->tel = $tel;

        return $this;
    }

    public function getFax(): ?string
    {
        return $this->fax;
    }

    public function setFax(string $fax): self
    {
        $this->fax = $fax;

        return $this;
    }

    public function getNomEmployeur(): ?string
    {
        return $this->nomEmployeur;
    }

    public function setNomEmployeur(string $nomEmployeur): self
    {
        $this->nomEmployeur = $nomEmployeur;

        return $this;
    }

    public function getUneVille(): ?Ville
    {
        return $this->uneVille;
    }

    public function setUneVille(?Ville $uneVille): self
    {
        $this->uneVille = $uneVille;

        return $this;
    }
}
