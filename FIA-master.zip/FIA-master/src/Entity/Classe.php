<?php

namespace App\Entity;

use App\Repository\ClasseRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=ClasseRepository::class)
 */
class Classe
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $libelle;

    /**
     * @ORM\OneToMany(targetEntity=Apprenti::class, mappedBy="uneClasse")
     */
    private $lesApprentisParClasse;

    public function __construct()
    {
        $this->lesApprentisParClasse = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getLibelle(): ?string
    {
        return $this->libelle;
    }

    public function setLibelle(string $libelle): self
    {
        $this->libelle = $libelle;

        return $this;
    }

    /**
     * @return Collection|Apprenti[]
     */
    public function getLesApprentisParClasse(): Collection
    {
        return $this->lesApprentisParClasse;
    }

    public function addLesApprentisParClasse(Apprenti $lesApprentisParClasse): self
    {
        if (!$this->lesApprentisParClasse->contains($lesApprentisParClasse)) {
            $this->lesApprentisParClasse[] = $lesApprentisParClasse;
            $lesApprentisParClasse->setUneClasse($this);
        }

        return $this;
    }

    public function removeLesApprentisParClasse(Apprenti $lesApprentisParClasse): self
    {
        if ($this->lesApprentisParClasse->removeElement($lesApprentisParClasse)) {
            // set the owning side to null (unless already changed)
            if ($lesApprentisParClasse->getUneClasse() === $this) {
                $lesApprentisParClasse->setUneClasse(null);
            }
        }

        return $this;
    }
}
