<?php

namespace App\Entity;

use App\Repository\RepresentantRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=RepresentantRepository::class)
 */
class Representant
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $nom;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $adresse;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $adressePlus;

    /**
     * @ORM\Column(type="string", length=12)
     */
    private $tel;

    /**
     * @ORM\ManyToOne(targetEntity=Ville::class)
     * @ORM\JoinColumn(nullable=false)
     */
    private $uneVille;

    /**
     * @ORM\ManyToOne(targetEntity=Profession::class)
     * @ORM\JoinColumn(nullable=false)
     */
    private $uneProfession;

    /**
     * @ORM\OneToMany(targetEntity=Parenter::class, mappedBy="unRepresentant")
     */
    private $lesApprentis;

    public function __construct()
    {
        $this->lesApprentis = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNom(): ?string
    {
        return $this->nom;
    }

    public function setNom(string $nom): self
    {
        $this->nom = $nom;

        return $this;
    }

    public function getAdresse(): ?string
    {
        return $this->adresse;
    }

    public function setAdresse(string $adresse): self
    {
        $this->adresse = $adresse;

        return $this;
    }

    public function getAdressePlus(): ?string
    {
        return $this->adressePlus;
    }

    public function setAdressePlus(?string $adressePlus): self
    {
        $this->adressePlus = $adressePlus;

        return $this;
    }

    public function getTel(): ?string
    {
        return $this->tel;
    }

    public function setTel(string $tel): self
    {
        $this->tel = $tel;

        return $this;
    }

    public function getUneVille(): ?Ville
    {
        return $this->uneVille;
    }

    public function setUneVille(?Ville $uneVille): self
    {
        $this->uneVille = $uneVille;

        return $this;
    }

    public function getUneProfession(): ?Profession
    {
        return $this->uneProfession;
    }

    public function setUneProfession(?Profession $uneProfession): self
    {
        $this->uneProfession = $uneProfession;

        return $this;
    }

    /**
     * @return Collection|Parenter[]
     */
    public function getLesApprentis(): Collection
    {
        return $this->lesApprentis;
    }

    public function addLesApprenti(Parenter $lesApprenti): self
    {
        if (!$this->lesApprentis->contains($lesApprenti)) {
            $this->lesApprentis[] = $lesApprenti;
            $lesApprenti->setUnRepresentant($this);
        }

        return $this;
    }

    public function removeLesApprenti(Parenter $lesApprenti): self
    {
        if ($this->lesApprentis->removeElement($lesApprenti)) {
            // set the owning side to null (unless already changed)
            if ($lesApprenti->getUnRepresentant() === $this) {
                $lesApprenti->setUnRepresentant(null);
            }
        }

        return $this;
    }
}
