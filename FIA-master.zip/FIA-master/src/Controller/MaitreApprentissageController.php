<?php

namespace App\Controller;

use App\Entity\MaitreApprentissage;
use App\Form\MaitreApprentissageType;
use App\Repository\MaitreApprentissageRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

/**
 * @Route("/maitre/apprentissage")
 */
class MaitreApprentissageController extends AbstractController
{
    /**
     * @Route("/", name="maitre_apprentissage_index", methods={"GET"})
     */
    public function index(MaitreApprentissageRepository $maitreApprentissageRepository): Response
    {
        return $this->render('maitre_apprentissage/index.html.twig', [
            'maitre_apprentissages' => $maitreApprentissageRepository->findAll(),
        ]);
    }

    /**
     * @Route("/new", name="maitre_apprentissage_new", methods={"GET","POST"})
     */
    public function new(Request $request): Response
    {
        $maitreApprentissage = new MaitreApprentissage();
        $form = $this->createForm(MaitreApprentissageType::class, $maitreApprentissage);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($maitreApprentissage);
            $entityManager->flush();

            return $this->redirectToRoute('maitre_apprentissage_index');
        }

        return $this->render('maitre_apprentissage/new.html.twig', [
            'maitre_apprentissage' => $maitreApprentissage,
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/{id}", name="maitre_apprentissage_show", methods={"GET"})
     */
    public function show(MaitreApprentissage $maitreApprentissage): Response
    {
        return $this->render('maitre_apprentissage/show.html.twig', [
            'maitre_apprentissage' => $maitreApprentissage,
        ]);
    }

    /**
     * @Route("/{id}/edit", name="maitre_apprentissage_edit", methods={"GET","POST"})
     */
    public function edit(Request $request, MaitreApprentissage $maitreApprentissage): Response
    {
        $form = $this->createForm(MaitreApprentissageType::class, $maitreApprentissage);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $this->getDoctrine()->getManager()->flush();

            return $this->redirectToRoute('maitre_apprentissage_index');
        }

        return $this->render('maitre_apprentissage/edit.html.twig', [
            'maitre_apprentissage' => $maitreApprentissage,
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/{id}", name="maitre_apprentissage_delete", methods={"DELETE"})
     */
    public function delete(Request $request, MaitreApprentissage $maitreApprentissage): Response
    {
        if ($this->isCsrfTokenValid('delete'.$maitreApprentissage->getId(), $request->request->get('_token'))) {
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->remove($maitreApprentissage);
            $entityManager->flush();
        }

        return $this->redirectToRoute('maitre_apprentissage_index');
    }
}
