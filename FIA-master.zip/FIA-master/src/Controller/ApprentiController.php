<?php

namespace App\Controller;

use App\Entity\Apprenti;
use App\Entity\Utilisateur;
use App\Form\ApprentiType;
use App\Repository\ApprentiRepository;
use App\Entity\Ville;
use App\Entity\Promotion;
use App\Entity\Classe;
use App\Entity\Diplome;
use App\Entity\Banque;
use App\Entity\MaitreApprentissage;
use App\Entity\Specialite;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

/**
 * @Route("/apprenti")
 */
class ApprentiController extends AbstractController
{
    /**
     * @Route("/", name="apprenti_index", methods={"GET"})
     */
    public function index(ApprentiRepository $apprentiRepository): Response
    {
        return $this->render('apprenti/index.html.twig', [
            'lesUtilisateurs' => $this->getDoctrine()->getRepository(Utilisateur::class)->findAll(),
            'apprentis' => $apprentiRepository->findAll(),
        ]);
    }

    /**
     * @Route("/new", name="apprenti_new", methods={"GET","POST"})
     */
    public function new(Request $request): Response
    {
        $apprenti = new Apprenti();
        $form = $this->createForm(ApprentiType::class, $apprenti);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($apprenti);
            $entityManager->flush();

            return $this->redirectToRoute('apprenti_index');
        }

        return $this->render('apprenti/new.html.twig', [
            'apprenti'       => $apprenti,
            'lesVilles'      => $this->getDoctrine()->getRepository(Ville::class)->findAll(),
            'lesPromotions'  => $this->getDoctrine()->getRepository(Promotion::class)->findAll(),
            'lesClasses'     => $this->getDoctrine()->getRepository(Classe::class)->findAll(),
            'lesDiplomes'    => $this->getDoctrine()->getRepository(Diplome::class)->findAll(),
            'lesBanques'     => $this->getDoctrine()->getRepository(Banque::class)->findAll(),
            'lesMa'          => $this->getDoctrine()->getRepository(MaitreApprentissage::class)->findAll(),
            'lesSpe'         => $this->getDoctrine()->getRepository(Specialite::class)->findAll(),
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/{id}", name="apprenti_show", methods={"GET"})
     */
    public function show(Apprenti $apprenti): Response
    {
        return $this->render('apprenti/show.html.twig', [
            'apprenti' => $apprenti,
        ]);
    }

    /**
     * @Route("/{id}/edit", name="apprenti_edit", methods={"GET","POST"})
     */
    public function edit(Request $request, Apprenti $apprenti): Response
    {
        $form = $this->createForm(ApprentiType::class, $apprenti);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $this->getDoctrine()->getManager()->flush();

            return $this->redirectToRoute('apprenti_index');
        }

        return $this->render('apprenti/edit.html.twig', [
            'apprenti' => $apprenti,
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/{id}", name="apprenti_delete", methods={"DELETE"})
     */
    public function delete(Request $request, Apprenti $apprenti): Response
    {
        if ($this->isCsrfTokenValid('delete'.$apprenti->getId(), $request->request->get('_token'))) {
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->remove($apprenti);
            $entityManager->flush();
        }

        return $this->redirectToRoute('apprenti_index');
    }
}
