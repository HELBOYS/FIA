<?php

namespace App\Form;

use App\Entity\Apprenti;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class ApprentiType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        // $builder
        //     ->add('nom')
        //     ->add('prenom')
        //     ->add('sexe')
        //     ->add('adresse')
        //     ->add('adressePlus')
        //     ->add('dateNaiss')
        //     ->add('tel')
        //     ->add('mail')
        //     ->add('IBAN')
        //     ->add('anneeObentionDiplome')
        //     ->add('lieuNaiss')
        //     ->add('unePromotion')
        //     ->add('uneClasse')
        //     ->add('unDiplome')
        //     ->add('uneBanque')
        //     ->add('unMA')
        //     ->add('uneSpecialite')
        //     ->add('unUtilisateur')
        // ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Apprenti::class,
        ]);
    }
}
